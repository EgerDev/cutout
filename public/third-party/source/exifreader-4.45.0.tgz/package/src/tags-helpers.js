/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

import Constants from './constants.js';
import Types from './types.js';
import TagNames, {IFD_TYPE_0TH, IFD_TYPE_1ST, IFD_TYPE_PENTAX} from './tag-names.js';
import {IFD_ENTRY_LENGTH, TIFF_IFD_OFFSET_OFFSET} from './tiff-constants.js';
import {NOOP_TAG_FILTER} from './tag-filter.js';

// Measured across the test corpus, the most demanding parse decodes tag
// values totalling 1.2241 times the size of the buffer they are read from
// (deliberately faulty files parsed with includeUnknown; real images peak
// near 0.81x, as some tags legitimately read overlapping bytes), so a budget
// of 4x is 3.27 times that worst case. The multiple is expensive here: a
// decoded byte was measured to cost about 16 bytes of heap, mostly as an
// array element plus its share of the joined description string.
const MAX_VALUE_SIZE_PER_BUFFER_SIZE = 4;

const getTagValueAt = {
    1: Types.getByteAt,
    2: Types.getAsciiAt,
    3: Types.getShortAt,
    4: Types.getLongAt,
    5: Types.getRationalAt,
    7: Types.getUndefinedAt,
    9: Types.getSlongAt,
    10: Types.getSrationalAt,
    13: Types.getIfdPointerAt
};

export function get0thIfdOffset(dataView, tiffHeaderOffset, byteOrder) {
    const offset = tiffHeaderOffset + TIFF_IFD_OFFSET_OFFSET;
    if (offset + Types.getTypeSize('LONG') > dataView.byteLength) {
        return undefined;
    }
    return tiffHeaderOffset
        + Types.getLongAt(dataView, offset, byteOrder);
}

/**
 * Reads the tags of an IFD, and for a 0th IFD also those of the thumbnail IFD
 * it points to.
 *
 * @param {{remaining: number}} [valueBudget] - Caps the total size of the
 * decoded tag values, see getValueBudget. Pass the same object to several
 * calls to bound them together; omit it to give this call its own budget.
 * @returns {Object} The read tags, keyed by tag name.
 */
export function readIfd(
    dataView,
    ifdType,
    offsetOrigin,
    offset,
    byteOrder,
    includeUnknown,
    computed = false,
    tagFilter = NOOP_TAG_FILTER,
    groupKey = 'exif',
    valueBudget = getValueBudget(dataView)
) {
    const FIELD_COUNT_SIZE = Types.getTypeSize('SHORT');
    const FIELD_SIZE = IFD_ENTRY_LENGTH;

    const tags = {};
    const numberOfFields = getNumberOfFields(dataView, offset, byteOrder);

    offset += FIELD_COUNT_SIZE;
    for (let fieldIndex = 0; fieldIndex < numberOfFields; fieldIndex++) {
        if (offset + FIELD_SIZE > dataView.byteLength) {
            break;
        }

        const tag = readTag(
            dataView,
            ifdType,
            offsetOrigin,
            offset,
            byteOrder,
            includeUnknown,
            tagFilter,
            groupKey,
            valueBudget
        );
        if (tag !== undefined) {
            tags[tag.name] = {
                'id': tag.id,
                'value': tag.value,
                'description': tag.description
            };
            if (computed) {
                tags[tag.name].computed = getComputedTagValue(tag.tagType, tag.value);
            }
            if (tag.name === 'MakerNote' || (ifdType === IFD_TYPE_PENTAX && tag.name === 'LevelInfo')) {
                tags[tag.name].__offset = tag.__offset;
            }
        }

        offset += FIELD_SIZE;
    }

    if (Constants.USE_THUMBNAIL && (offset < dataView.byteLength - Types.getTypeSize('LONG'))) {
        const nextIfdOffset = Types.getLongAt(dataView, offset, byteOrder);
        if (nextIfdOffset !== 0 && ifdType === IFD_TYPE_0TH) {
            if (tagFilter.shouldParseGroup('thumbnail')) {
                tags['Thumbnail'] = readIfd(
                    dataView,
                    IFD_TYPE_1ST,
                    offsetOrigin,
                    offsetOrigin + nextIfdOffset,
                    byteOrder,
                    includeUnknown,
                    computed,
                    tagFilter,
                    'thumbnail',
                    valueBudget
                );
            }
        }
    }

    return tags;
}

/**
 * Creates a budget for the total size of the tag values decoded from a buffer.
 *
 * Tags can legitimately point at overlapping parts of the buffer, and unknown
 * tags of a faulty file can do so with large sizes, so the total is allowed to
 * be a multiple of the buffer size. The multiple keeps the total proportional
 * to the input, which is what stops a crafted file from having thousands of
 * tags decode the same bytes over and over.
 *
 * @param {DataView} dataView - The buffer the values are decoded from.
 * @returns {{remaining: number}} The budget, in bytes left to decode.
 */
export function getValueBudget(dataView) {
    return {remaining: dataView.byteLength * MAX_VALUE_SIZE_PER_BUFFER_SIZE};
}

function getNumberOfFields(dataView, offset, byteOrder) {
    if (offset + Types.getTypeSize('SHORT') <= dataView.byteLength) {
        return Types.getShortAt(dataView, offset, byteOrder);
    }
    return 0;
}

function readTag(
    dataView,
    ifdType,
    offsetOrigin,
    offset,
    byteOrder,
    includeUnknown = false,
    tagFilter = NOOP_TAG_FILTER,
    groupKey = 'exif',
    valueBudget
) {
    const TAG_CODE_IPTC_NAA = 0x83bb;
    const TAG_TYPE_OFFSET = Types.getTypeSize('SHORT');
    const TAG_COUNT_OFFSET = TAG_TYPE_OFFSET + Types.getTypeSize('SHORT');
    const TAG_VALUE_OFFSET = TAG_COUNT_OFFSET + Types.getTypeSize('LONG');

    const tagCode = Types.getShortAt(dataView, offset, byteOrder);
    const tagType = Types.getShortAt(dataView, offset + TAG_TYPE_OFFSET, byteOrder);
    const tagCount = Types.getLongAt(dataView, offset + TAG_COUNT_OFFSET, byteOrder);
    let tagValue;
    let tagValueOffset;

    if (Types.typeSizes[tagType] === undefined || (!includeUnknown && TagNames[ifdType][tagCode] === undefined)) {
        return undefined;
    }

    const tagName = getTagName(ifdType, tagCode);
    if (!tagFilter.shouldParseTag(groupKey, tagName, tagCode)) {
        return undefined;
    }

    if (tagValueFitsInOffsetSlot(tagType, tagCount)) {
        tagValueOffset = offset + TAG_VALUE_OFFSET;
        tagValue = getTagValue(dataView, tagValueOffset, tagType, tagCount, byteOrder);
    } else {
        tagValueOffset = Types.getLongAt(dataView, offset + TAG_VALUE_OFFSET, byteOrder);
        if (tagValueFitsInDataView(dataView, offsetOrigin, tagValueOffset, tagType, tagCount)) {
            const forceByteType = tagCode === TAG_CODE_IPTC_NAA;
            const boundedTagCount = getBoundedTagCount(valueBudget.remaining, tagType, tagCount);
            valueBudget.remaining -= boundedTagCount * Types.typeSizes[tagType];
            tagValue = getTagValue(dataView, offsetOrigin + tagValueOffset, tagType, boundedTagCount, byteOrder, forceByteType);
        } else {
            tagValue = '<faulty value>';
        }
    }

    if (tagType === Types.tagTypes['ASCII']) {
        tagValue = splitNullSeparatedAsciiString(tagValue);
        tagValue = decodeAsciiValue(tagValue);
    }

    let tagDescription = tagValue;

    if (TagNames[ifdType][tagCode] !== undefined) {
        if ((TagNames[ifdType][tagCode]['name'] !== undefined) && (TagNames[ifdType][tagCode]['description'] !== undefined)) {
            try {
                tagDescription = TagNames[ifdType][tagCode]['description'](tagValue);
            } catch (error) {
                tagDescription = getDescriptionFromTagValue(tagValue);
            }
        } else if ((tagType === Types.tagTypes['RATIONAL']) || (tagType === Types.tagTypes['SRATIONAL'])) {
            tagDescription = '' + (tagValue[0] / tagValue[1]);
        } else {
            tagDescription = getDescriptionFromTagValue(tagValue);
        }
    }

    return {
        id: tagCode,
        name: tagName,
        value: tagValue,
        description: tagDescription,
        tagType,
        __offset: tagValueOffset
    };
}

function getTagName(ifdType, tagCode) {
    if (TagNames[ifdType][tagCode] !== undefined) {
        if (typeof TagNames[ifdType][tagCode] === 'string') {
            return TagNames[ifdType][tagCode];
        }
        if (TagNames[ifdType][tagCode].name) {
            return TagNames[ifdType][tagCode].name;
        }
    }

    return `undefined-${tagCode}`;
}

function tagValueFitsInOffsetSlot(tagType, tagCount) {
    return Types.typeSizes[tagType] * tagCount <= Types.getTypeSize('LONG');
}

function getTagValue(dataView, offset, type, count, byteOrder, forceByteType = false) {
    let value = [];

    if (forceByteType) {
        count = count * Types.typeSizes[type];
        type = Types.tagTypes['BYTE'];
    }
    for (let valueIndex = 0; valueIndex < count; valueIndex++) {
        value.push(getTagValueAt[type](dataView, offset, byteOrder));
        offset += Types.typeSizes[type];
    }

    if (type === Types.tagTypes['ASCII']) {
        value = Types.getAsciiValue(value);
    } else if (value.length === 1) {
        value = value[0];
    }

    return value;
}

function tagValueFitsInDataView(dataView, offsetOrigin, tagValueOffset, tagType, tagCount) {
    return offsetOrigin + tagValueOffset + Types.typeSizes[tagType] * tagCount <= dataView.byteLength;
}

// Draws each out-of-slot value from the shared budget, so a crafted file
// cannot have thousands of tags decode the same bytes over and over. Real
// files, including ones whose tags read overlapping bytes, stay far below it.
function getBoundedTagCount(remainingBudget, tagType, tagCount) {
    const boundedCount = Math.min(tagCount, Math.floor(remainingBudget / Types.typeSizes[tagType]));
    if (boundedCount === 1 && tagCount > 1) {
        // Most types unwrap a single element into a bare value, which would
        // make a truncated value look like a genuine one-element one. Return
        // the empty value a zero count already produces instead.
        return 0;
    }
    return boundedCount;
}

function splitNullSeparatedAsciiString(string) {
    const tagValue = [];
    let i = 0;

    for (let j = 0; j < string.length; j++) {
        if (string[j] === '\x00') {
            i++;
            continue;
        }
        if (tagValue[i] === undefined) {
            tagValue[i] = '';
        }
        tagValue[i] += string[j];
    }

    return tagValue;
}

function decodeAsciiValue(asciiValue) {
    try {
        return asciiValue.map((value) => decodeURIComponent(escape(value)));
    } catch (error) {
        return asciiValue;
    }
}

function getDescriptionFromTagValue(tagValue) {
    if (tagValue instanceof Array) {
        return tagValue.join(', ');
    }
    return tagValue;
}

function getComputedTagValue(tagType, value) {
    if (tagType === Types.tagTypes['ASCII']) {
        if (Array.isArray(value) && value.length === 1) {
            return value[0];
        }

        return value;
    }

    if (tagType === Types.tagTypes['RATIONAL'] || tagType === Types.tagTypes['SRATIONAL']) {
        if (isSingleRationalValue(value)) {
            return getComputedRationalValue(value);
        }

        if (Array.isArray(value)) {
            return value.map((rational) => getComputedRationalValue(rational));
        }

        return value;
    }

    return value;
}

function isSingleRationalValue(value) {
    if (!Array.isArray(value) || value.length !== 2) {
        return false;
    }

    return typeof value[0] === 'number' && typeof value[1] === 'number';
}

function getComputedRationalValue(rational) {
    if (!Array.isArray(rational) || rational.length !== 2) {
        return rational;
    }

    const numerator = rational[0];
    const denominator = rational[1];
    if (!Number.isFinite(numerator) || !Number.isFinite(denominator)) {
        return rational;
    }

    if (denominator === 0) {
        return null;
    }

    return numerator / denominator;
}
